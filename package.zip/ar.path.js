

const jsonData =  {
    QR1:`https://biztel.co.in/XCODE001`,
    QR2:'https://biztel.co.in/XCODE001',
    QR3:`https://biztel.co.in/XCODE001`,
    QR4:'https://biztel.co.in/XCODE001',
    QR5:`https://biztel.co.in/XCODE001`,
}


module.exports = jsonData




